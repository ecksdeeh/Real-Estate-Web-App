<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <img src="logo.png" alt="Logo" class="logo" />

  <main class="form-container">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <p>You have successfully logged in.</p>

    <div class="dashboard-actions">
      <a href="logout.php" class="button logout-btn">Logout</a>
    </div>
  </main>
</body>
</html>
