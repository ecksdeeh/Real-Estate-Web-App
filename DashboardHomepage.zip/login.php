<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = htmlspecialchars(trim($_POST['username_or_email']));
    $password = $_POST['password'];

    if (empty($username_or_email) || empty($password)) {
        header("Location: login.html?error=Please fill in all fields");
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username_or_email, $username_or_email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

           
            echo "<!DOCTYPE html>
            <html lang='en'>
            <head>
              <meta charset='UTF-8' />
              <meta name='viewport' content='width=device-width, initial-scale=1.0' />
              <title>Login Success</title>
              <link rel='stylesheet' href='styles.css' />
            </head>
            <body>
              <main class='form-container'>
                <h1>Login Successful</h1>
                <p>Welcome, " . htmlspecialchars($user['first_name']) . "!</p>
                <a href='login.html'>Go back</a>
              </main>
            </body>
            </html>";
            exit();
        } else {
            header("Location: login.html?error=Incorrect password");
            exit();
        }
    } else {
        header("Location: login.html?error=User not found");
        exit();
    }
}

if (password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];

   
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='UTF-8' />
      <meta name='viewport' content='width=device-width, initial-scale=1.0' />
      <title>Login Successful</title>
      <link rel='stylesheet' href='styles.css' />
      <meta http-equiv='refresh' content='3;url=dashboard.php' />
    </head>
    <body>
      <main class='form-container'>
        <h1>Login Successful!</h1>
        <p>Welcome, " . htmlspecialchars($user['first_name']) . ".</p>
        <p>Redirecting you to your dashboard...</p>
        <p><a href='dashboard.php'>Click here if you're not redirected</a></p>
      </main>
    </body>
    </html>";
    exit();
}
?>